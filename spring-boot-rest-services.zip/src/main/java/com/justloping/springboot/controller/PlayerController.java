package com.justloping.springboot.controller;

import java.net.URI;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.justloping.springboot.model.Player;
import com.justloping.springboot.service.PlayerService;

@RestController
public class PlayerController {

	@Autowired
	private PlayerService playerService;

	@GetMapping("/resources/data/")
	public List<Player> getPlayers() {
		return playerService.getAllPlayers();
	}

	@GetMapping("/resources/data/{data_id}")
	public ResponseEntity<Object> getSpecificPlayer(@PathVariable String data_id) {
		Player info = playerService.getPlayer(data_id);

		if (info == null)
			return ResponseEntity.notFound().build();

		return new ResponseEntity<Object>(
				info,
				HttpStatus.OK);
	}

	@DeleteMapping("/resources/data/{data_id}")
	public ResponseEntity<Object> deletePlayer(@PathVariable String data_id) {
		Player info = playerService.deletePlayer(data_id);

		if (info == null)
			return ResponseEntity.notFound().build();

		return new ResponseEntity<Object>(
				info,
				HttpStatus.OK);
	}

	@PostMapping("/resources/data/")
	public ResponseEntity<Object> newPlayer(@RequestBody Map<String, String> body) {
		String newId = playerService.addPlayer(body.get("name"), body.get("age"), body.get("locale"));

		body.put("id", newId);
		return new ResponseEntity<Object>(
				body,
				HttpStatus.OK);
	}

	@PutMapping("/resources/data/{data_id}")
	public ResponseEntity<Object> updatePlayer(@RequestBody Map<String, String> body, @PathVariable String data_id) {
		boolean result = playerService.updatePlayer(data_id, body);

		if (!result)
			return ResponseEntity.notFound().build();

		return ResponseEntity.noContent().build();
	}
}
