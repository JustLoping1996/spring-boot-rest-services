package com.justloping.springboot.model;

import java.util.List;
import java.util.Map;

public class Player {
	private String id;
	private String name;
	private int age;
	private String locale;	//I use NBA team abbreviation here, for example, bos

	public Player(String id, String name, String age, String locale) {
		this.id = id;
		this.name = name;
		setAge(age);
		this.locale = locale;
	}

	public Player(String id, String name, int age, String locale) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.locale = locale;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setAge(String age) {
		this.age = new Integer(age).intValue();
	}
	
	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	@Override
	public String toString() {
		return String.format("Player [id=%s, name=%s, age=%s, locale=%s]", id, name, age, locale);
	}
}