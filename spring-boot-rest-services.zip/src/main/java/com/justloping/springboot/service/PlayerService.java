package com.justloping.springboot.service;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.justloping.springboot.model.Player;

@Component
public class PlayerService {

	private static List<Player> players = new ArrayList<>();

	static {
		//Initialize Data
		Player gHayward = new Player("Player1", "Gordon Hayward", "28", "BOS");
		Player jTatum = new Player("Player2", "Jayson Tatum", "20", "BOS");
		Player kIrving = new Player("Player3", "Kyrie Irving", "26", "BOS");

		players.add(gHayward);
		players.add(jTatum);
		players.add(kIrving);
	}

	public List<Player> getAllPlayers() {
		return players;
	}

	public Player getPlayer(String playerId) {
		for (Player player : players) {
			if (player.getId().equals(playerId)) {
				return player;
			}
		}
		return null;
	}

	public String addPlayer(String name, String age, String locale) {
		int num = players.size() + 1;
		String newPlayerId = "Player" + num;

		Player player = new Player(newPlayerId, name, age, locale);

		return addPlayer(player);
	}

	public String addPlayer(Player info) {
		players.add(info);

		return info.getId();
	}

	public boolean updatePlayer(String playerId, Map<String, String> info) {
		for (Player player : players) {
			if (player.getId().equals(playerId)) {
				player.setAge(info.get("age"));
				player.setLocale(info.get("locale"));
				player.setName(info.get("name"));
				return true;
			}
		}
		return false;
	}

	public Player deletePlayer(String playerId) {
		for (Player player : players) {
			if (player.getId().equals(playerId)) {
				Player info = new Player(playerId, player.getName(), player.getAge(), player.getLocale());
				players.remove(player);
				return info;
			}
		}

		return null;
	}
}