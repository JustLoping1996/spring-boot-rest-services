package com.justloping.springboot.controller;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.justloping.springboot.model.Player;
import com.justloping.springboot.service.PlayerService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = PlayerController.class, secure = false)
public class PlayerControllerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private PlayerService playerService;

	Player mockPlayer = new Player("Player3", "Kyrie Irving", "26", "BOS");

	String examplePlayerJson = "{\"name\":\"Kyrie Irving\",\"age\":26,\"locale\":\"BOS\"}";

	@Test
	public void getSpecificPlayer() throws Exception {

		Mockito.when(
				playerService.getPlayer(Mockito.anyString())).thenReturn(mockPlayer);

		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				"/resources/data/Player3").accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		String expected = "{\"id\":\"Player3\",\"name\":\"Kyrie Irving\",\"age\":26,\"locale\":\"BOS\"}";

		JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
	}
}
